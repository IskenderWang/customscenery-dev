-------------------------------------------------------------------------------
Ust-Kamenogorsk Intl (UASK)
-------------------------------------------------------------------------------

This scenery pack was downloaded from the X-Plane Scenery Gateway: 

    http://gateway.x-plane.com/

Airport: Ust-Kamenogorsk Intl (UASK)

Uploaded by: MadJohn.

Authors Comments:

Add ATIS Freq and "Intl" in airport name

Installation Instructions:

To install this scenery, drag this entire folder into X-Plane's Custom Scenery
folder and re-start X-Plane.

The scenery packs shared via the X-Plane Scenery Gateway are free software; you
can redistribute it and/or modify it under the terms of the GNU General Public
License as published by the Free Software Foundation; either version 2 of the
License, or (at your option) any later version.  See the included COPYING file
for complete terms.
