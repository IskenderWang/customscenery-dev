-------------------------------------------------------------------------------
G 413 (RK21)
-------------------------------------------------------------------------------

Airport: G 413 (RK21)

Uploaded by: WEDbot.

Authors Comments:

Airport upload from X-Plane 10.32's default apt.dat

Installation Instructions:

To install this scenery, drag this entire folder into X-Plane's Custom Scenery
folder and re-start X-Plane.
