-------------------------------------------------------------------------------
Yamaguchi Ube (RJDC)
-------------------------------------------------------------------------------

This scenery pack was downloaded from the X-Plane Scenery Gateway: 

    http://gateway.x-plane.com/

Airport: Yamaguchi Ube (RJDC)

Uploaded by: zjoseph.

Authors Comments:

Changed airport name to lower case. Original airport by xibo, all credit goes to him.

Installation Instructions:

To install this scenery, drag this entire folder into X-Plane's Custom Scenery
folder and re-start X-Plane.

The scenery packs shared via the X-Plane Scenery Gateway are free software; you
can redistribute it and/or modify it under the terms of the GNU General Public
License as published by the Free Software Foundation; either version 2 of the
License, or (at your option) any later version.  See the included COPYING file
for complete terms.
