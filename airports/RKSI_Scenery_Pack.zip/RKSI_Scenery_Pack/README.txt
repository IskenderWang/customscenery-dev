-------------------------------------------------------------------------------
Seoul Incheon Intl (RKSI)
-------------------------------------------------------------------------------

This scenery pack was downloaded from the X-Plane Scenery Gateway: 

    http://gateway.x-plane.com/

Airport: Seoul Incheon Intl (RKSI)

Uploaded by: BG.

Authors Comments:

This is the final conclusion at the moment. Added taxi hold position and powered taxi start position markings recognised in the official airport diagram. Corrected small mistakes in ATC routes, Taxiway names and signs accordingly. Also mended very small gaps between the taxiways and shoulders found near the northwest part of the airport.

Installation Instructions:

To install this scenery, drag this entire folder into X-Plane's Custom Scenery
folder and re-start X-Plane.

The scenery packs shared via the X-Plane Scenery Gateway are free software; you
can redistribute it and/or modify it under the terms of the GNU General Public
License as published by the Free Software Foundation; either version 2 of the
License, or (at your option) any later version.  See the included COPYING file
for complete terms.
