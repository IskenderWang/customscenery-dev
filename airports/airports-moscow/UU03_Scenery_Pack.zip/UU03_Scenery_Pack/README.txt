-------------------------------------------------------------------------------
[H] Anosino-2 (UU03)
-------------------------------------------------------------------------------

Airport: [H] Anosino-2 (UU03)

Uploaded by: .

Authors Comments:



Installation Instructions:

To install this scenery, drag this entire folder into X-Plane's Custom Scenery
folder and re-start X-Plane.
