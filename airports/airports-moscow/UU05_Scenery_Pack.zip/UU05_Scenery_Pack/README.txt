-------------------------------------------------------------------------------
[H] Belaya Dacha (UU05)
-------------------------------------------------------------------------------

Airport: [H] Belaya Dacha (UU05)

Uploaded by: .

Authors Comments:



Installation Instructions:

To install this scenery, drag this entire folder into X-Plane's Custom Scenery
folder and re-start X-Plane.
