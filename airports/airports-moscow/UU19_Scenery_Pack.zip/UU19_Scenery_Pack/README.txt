-------------------------------------------------------------------------------
[H] Zaokskie Prostory (UU19)
-------------------------------------------------------------------------------

Airport: [H] Zaokskie Prostory (UU19)

Uploaded by: .

Authors Comments:



Installation Instructions:

To install this scenery, drag this entire folder into X-Plane's Custom Scenery
folder and re-start X-Plane.
