-------------------------------------------------------------------------------
[H] Vlasikha (UU11)
-------------------------------------------------------------------------------

Airport: [H] Vlasikha (UU11)

Uploaded by: .

Authors Comments:



Installation Instructions:

To install this scenery, drag this entire folder into X-Plane's Custom Scenery
folder and re-start X-Plane.
