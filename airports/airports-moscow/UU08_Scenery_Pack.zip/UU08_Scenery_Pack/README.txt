-------------------------------------------------------------------------------
[H] Vera (UU08)
-------------------------------------------------------------------------------

Airport: [H] Vera (UU08)

Uploaded by: .

Authors Comments:



Installation Instructions:

To install this scenery, drag this entire folder into X-Plane's Custom Scenery
folder and re-start X-Plane.
