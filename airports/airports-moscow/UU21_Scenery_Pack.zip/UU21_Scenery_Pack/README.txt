-------------------------------------------------------------------------------
[H] Ivakino (UU21)
-------------------------------------------------------------------------------

Airport: [H] Ivakino (UU21)

Uploaded by: .

Authors Comments:



Installation Instructions:

To install this scenery, drag this entire folder into X-Plane's Custom Scenery
folder and re-start X-Plane.
